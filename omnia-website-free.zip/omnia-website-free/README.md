# Omnia AI website (100% free setup)

Everything here uses free plans: GitHub (code), Vercel Hobby (hosting), Google AI Studio Gemini API (AI, free tier, no card).

## Steps
1. Get a free key: https://aistudio.google.com  > "Get API key" > Create key. Save it.
2. Create a free GitHub account, make a new PRIVATE repository, upload ALL files from this folder (keep the `api` folder; `index.html` must be at the top level).
3. Create a free Vercel account (Continue with GitHub), choose the Hobby plan.
4. Add New > Project > import your repository.
5. Open Environment Variables and add:
   - GEMINI_API_KEY = your key
   - ACCESS_CODE = any secret word (so strangers cannot use up your free quota)
6. Click Deploy. Your site will be at yourname.vercel.app (free address, no domain needed).

## Good to know
- Free tier means limited requests per minute and per day. If you see "Free limit reached", wait a while. Google can change free limits any time.
- Free-tier requests may be used by Google to improve its products. Do not type private data.
- Vercel Hobby is for personal, non-commercial use. If you start charging users, move to a paid plan.
- Image, code and video quality is a bit lower than with premium models.
- To change the model, set GEMINI_MODEL in Vercel (for example a newer Flash model) and Redeploy.
- Changing an environment variable needs a Redeploy to take effect.
